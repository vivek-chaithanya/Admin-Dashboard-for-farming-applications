from django.db import models
from django.conf import settings

class UserAuthToken(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    access_token = models.TextField()
    last_login = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'usertoken'
        app_label = 'models_app'

    def __str__(self):
        return f"{self.user.username or self.user.email} - Auth Token"
    
    