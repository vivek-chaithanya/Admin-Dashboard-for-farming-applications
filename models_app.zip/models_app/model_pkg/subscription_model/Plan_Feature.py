from django.db import models
from ..subscription_model.Plans import MainPlan, TopUpPlan, EnterprisePlan
from ..subscription_model.Feature import Feature

# -----------------------------
# Plan-Feature Mapping with Duration
# -----------------------------

class MainPlanFeature(models.Model):
    plan = models.ForeignKey(MainPlan, on_delete=models.CASCADE)
    feature = models.ForeignKey(Feature, on_delete=models.CASCADE)
    max_count = models.IntegerField()
    duration_days = models.IntegerField()  # how long this feature is valid (per cycle)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        app_label = 'models_app'
        db_table = 'main_plan_feature'


class TopUpPlanFeature(models.Model):
    plan = models.ForeignKey(TopUpPlan, on_delete=models.CASCADE)
    feature = models.ForeignKey(Feature, on_delete=models.CASCADE)
    max_count = models.IntegerField()
    duration_days = models.IntegerField()

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        app_label = 'models_app'
        db_table = 'topup_plan_feature'

class EnterprisePlanFeature(models.Model):
    plan = models.ForeignKey(EnterprisePlan, on_delete=models.CASCADE)
    feature = models.ForeignKey(Feature, on_delete=models.CASCADE)
    max_count = models.IntegerField()
    duration_days = models.IntegerField()

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        app_label = 'models_app'
        db_table = 'enterprise_plan_feature'