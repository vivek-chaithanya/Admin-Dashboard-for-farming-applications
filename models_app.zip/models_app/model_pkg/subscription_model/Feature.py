from django.db import models

# -----------------------------
# Feature Type List
# -----------------------------

class FeatureType(models.Model):
    name = models.CharField(max_length=100, unique=True)  # e.g. "AI", "Basic", "Premium"
    description = models.TextField(blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        app_label = 'models_app'
        db_table = 'feature_type'

    def __str__(self):
        return self.name


# -----------------------------
# Feature List
# -----------------------------

class Feature(models.Model):
    name = models.CharField(max_length=100, unique=True)
    feature_type = models.ForeignKey(FeatureType, on_delete=models.CASCADE, related_name='features')

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        app_label = 'models_app'
        db_table = 'feature'