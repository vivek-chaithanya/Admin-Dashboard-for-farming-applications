from django.db import models
from ..User import CustomUser
from ..subscription_model.Plan_Feature import MainPlan, TopUpPlan, EnterprisePlan


# -----------------------------
# User Plan Assignments with Expiry
# -----------------------------

class MainUserPlan(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    plan = models.ForeignKey(MainPlan, on_delete=models.CASCADE)
    start_date = models.DateField()
    end_date = models.DateField()
    expire_at = models.DateTimeField()
    is_active = models.BooleanField(default=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        app_label = 'models_app'
        db_table = 'main_user_plan'



class TopUpUserPlan(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    plan = models.ForeignKey(TopUpPlan, on_delete=models.CASCADE)
    purchase_date = models.DateTimeField(auto_now_add=True)
    expire_at = models.DateTimeField()
    is_active = models.BooleanField(default=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        app_label = 'models_app'
        db_table = 'topup_user_plan'


class EnterpriseUserPlan(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    plan = models.ForeignKey(EnterprisePlan, on_delete=models.CASCADE)
    start_date = models.DateField()
    end_date = models.DateField()
    expire_at = models.DateTimeField()
    is_active = models.BooleanField(default=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        app_label = 'models_app'
        db_table = 'enterprise_user_plan'