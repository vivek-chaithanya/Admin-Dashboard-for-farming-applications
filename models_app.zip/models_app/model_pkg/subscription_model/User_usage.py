from django.db import models
from ..subscription_model.User_plan import MainUserPlan, TopUpUserPlan, EnterpriseUserPlan
from ..subscription_model.Feature import Feature

# -----------------------------
# Feature Usage Tracking
# -----------------------------

class MainPlanFeatureUsage(models.Model):
    user_plan = models.ForeignKey(MainUserPlan, on_delete=models.CASCADE)
    feature = models.ForeignKey(Feature, on_delete=models.CASCADE)
    max_count = models.IntegerField()
    used_count = models.IntegerField(default=0)
    duration_days = models.IntegerField()

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        app_label = 'models_app'
        db_table = 'main_plan_feature_usage'


class TopUpPlanFeatureUsage(models.Model):
    user_plan = models.ForeignKey(TopUpUserPlan, on_delete=models.CASCADE)
    feature = models.ForeignKey(Feature, on_delete=models.CASCADE)
    max_count = models.IntegerField()

    used_count = models.IntegerField(default=0)
    duration_days = models.IntegerField()

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        app_label = 'models_app'
        db_table = 'topup_plan_feature_usage'


class EnterprisePlanFeatureUsage(models.Model):
    user_plan = models.ForeignKey(EnterpriseUserPlan, on_delete=models.CASCADE)
    feature = models.ForeignKey(Feature, on_delete=models.CASCADE)
    max_count = models.IntegerField()

    used_count = models.IntegerField(default=0)
    duration_days = models.IntegerField()

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        app_label = 'models_app'
        db_table = 'enterprise_plan_feature_usage'