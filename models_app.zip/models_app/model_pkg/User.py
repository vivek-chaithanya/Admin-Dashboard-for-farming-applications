from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
from django.utils import timezone


class CustomUserManager(BaseUserManager):
    def create_user(self,email=None, password=None, **extra_fields):
        if not email:
            raise ValueError("The Email must be set")
        email = self.normalize_email(email)

        user = self.model(email=email, **extra_fields)
        user.set_password(password)  # hashes password properly
        user.save(using=self._db)
        return user


    def create_superuser(self, email=None, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)

        if extra_fields.get("is_staff") is not True:
            raise ValueError("Superuser must have is_staff=True.")
        if extra_fields.get("is_superuser") is not True:
            raise ValueError("Superuser must have is_superuser=True.")

        return self.create_user( email, password, **extra_fields,username=email)

class CustomUser(AbstractBaseUser, PermissionsMixin):
    username = models.CharField(max_length=150,blank=True,null=True)
    email = models.EmailField(null=True, blank=True, unique=True)
    phone_number = models.CharField(max_length=15, blank=True,unique=True,null=True)
    google_id = models.CharField(max_length=255, blank=True, null=True,unique=True)
    avatar = models.CharField(max_length=255, blank=True, null=True)
    # name = models.CharField(max_length=100)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    date_joined = models.DateTimeField(default=timezone.now)

    objects = CustomUserManager()

    USERNAME_FIELD = 'email'

    class Meta:
        app_label = 'models_app'
        db_table = 'custom_user'

    def __str__(self):
        if self.username:
            return self.username
        elif self.email:
            return self.email
        elif self.phone_number:
            return self.phone_number
        else:
            return "Unknown"
        # return self.email or self.phone_number