from django.db import models

from .User import CustomUser

class Language(models.Model):
    name=models.CharField()
    class Meta:
        app_label = 'models_app'
        db_table = 'languages'

class Preferences(models.Model):
    # language=models.ForeignKey(Language,on_delete=models.CASCADE)
    # theme=models.CharField
    user=models.OneToOneField(CustomUser,on_delete=models.CASCADE,blank=True,null=True)
    class Meta:
        app_label = 'models_app'
        db_table = 'user_preferences'