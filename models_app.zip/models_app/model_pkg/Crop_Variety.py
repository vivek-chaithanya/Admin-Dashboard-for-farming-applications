from django.db import models

class Crop(models.Model):
    """
    Base crop model (e.g., Wheat, Rice, Maize).
    """
    name = models.CharField(max_length=100, unique=True)
    icon_url = models.URLField(max_length=300, blank=True, null=True, help_text="Link to crop icon image")

    def __str__(self):
        return self.name

    class Meta:
        app_label = 'models_app'
        db_table = 'crop'


class CropVariety(models.Model):
    """
    Specific crop varieties (e.g., IR64 Rice, HD2967 Wheat).
    """
    crop = models.ForeignKey(Crop, on_delete=models.CASCADE, related_name='varieties')
    name = models.CharField(max_length=100)
    is_primary = models.BooleanField(default=False, help_text="Mark this variety as the primary one for the crop.")

    class Meta:
        app_label = 'models_app'
        db_table = 'crop_variety'
        unique_together = ('crop', 'name')
        verbose_name_plural = 'Crop Varieties'

    def __str__(self):
        return f"{self.name} ({self.crop.name})"

    def save(self, *args, **kwargs):
        # If marked as primary, unset others for the same crop
        if self.is_primary:
            CropVariety.objects.filter(crop=self.crop, is_primary=True).exclude(pk=self.pk).update(is_primary=False)
        super().save(*args, **kwargs)
    
