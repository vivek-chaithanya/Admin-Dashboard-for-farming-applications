from django.db import models
class IrrigationMethods(models.Model):
    name=models.CharField()
    class Meta:
        db_table='irrigation_methods'
        app_label='models_app'