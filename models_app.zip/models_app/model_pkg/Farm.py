from django.db import models
from .User import CustomUser
class Farm(models.Model):
    name = models.CharField(max_length=25)  
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE,blank=False)
    class Meta:
        app_label = 'models_app'  

    def __str__(self):
        return self.name  


