from django.contrib.gis.db import models as geomodels
from django.db import models
from .User import CustomUser
class Device(models.Model):
    name = models.CharField(max_length=50, unique=True)
    location = geomodels.PointField(geography=True, null=True, blank=True, help_text="Device location as a geographic point")
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, blank=True,null=True)
    class Meta:
        db_table = 'device'
        app_label = 'models_app'  # optional

    def __str__(self):
        return self.name
