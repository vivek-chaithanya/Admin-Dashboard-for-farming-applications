import os
from uuid import uuid4
from django.db import models
from django.contrib.gis.db import models as geomodels
from django.db.models import JSONField

from .asset.upload_utils import asset_upload_to  
from .Irrigation import IrrigationMethods 
from .Farm import Farm
from .Device import Device
from .Crop_Variety import Crop, CropVariety
from .User import CustomUser
from storages.backends.s3boto3 import S3Boto3Storage


class Field(models.Model):
    """
    Represents a plot/field inside a farm with crop details and geolocation.
    Stores a geographic polygon and human-readable location name.
    """
    name = models.CharField(max_length=50)
    farm = models.ForeignKey(Farm, on_delete=models.CASCADE, related_name='fields')
    device = models.ForeignKey(Device, on_delete=models.SET_NULL, null=True, blank=True, related_name='fields')
    crop = models.ForeignKey(Crop, on_delete=models.SET_NULL, null=True, blank=True, related_name='fields')
    crop_variety = models.ForeignKey(CropVariety, on_delete=models.SET_NULL, null=True, blank=True, related_name='fields')
    user =  models.ForeignKey(CustomUser,on_delete=models.CASCADE,blank=False,null=True)
    # GeoDjango PolygonField (requires PostGIS)
    boundary = geomodels.PolygonField(geography=True, null=True, blank=True, help_text="Geo polygon of the field")

    # Optional: human-readable location name or address
    location_name = models.CharField(max_length=255, null=True, blank=True, help_text="e.g., 'Near Canal, Block A'")

    area = JSONField(null=True, blank=True, help_text="Area sizes in different units (sqm, acres, hectares)")

    image = models.ImageField(upload_to=asset_upload_to,blank=True,null=True,storage=S3Boto3Storage())
    is_active = models.BooleanField(default=True)
    is_locked = models.BooleanField(default=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'field'
        app_label = 'models_app'
        ordering = ['name']
    
    def save(self, *args, **kwargs):
        if self.boundary:
            geom = self.boundary.clone()
            try:
                lon = geom.centroid.x
                utm_zone = int((lon + 180) / 6) + 1
                utm_srid = 32600 + utm_zone  # Northern hemisphere UTM zone
                geom.transform(utm_srid)
                area_sqm = geom.area
                self.area = {
                    "sqm": area_sqm,
                    "acres": area_sqm / 4046.86,
                    "hectares": area_sqm / 10000,
                }
            except Exception:
                self.area = None
        else:
            self.area = None

        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.name} ({self.farm.name})"

class CropLifecycleDates(models.Model):
    field=models.ForeignKey(Field,blank=False,on_delete=models.CASCADE)
    sowing_date = models.DateField(null=True, blank=True)
    harvesting_date = models.DateField(null=True, blank=True)

    class Meta:
        db_table='crop_lifecycle_dates'
        app_label='models_app'

class FieldIrrigationMethod(models.Model):
    field=models.ForeignKey(Field,blank=False,on_delete=models.CASCADE)
    irrigation_method=models.ForeignKey(IrrigationMethods,on_delete=models.CASCADE)
    class Meta:
        db_table='field_irrigation_methods'
        app_label='models_app'