from .Field import Field
from django.db import models
class SoilTexture(models.Model):
    name=models.CharField()
    #use this url field for db level validation
    icon=models.URLField()
    class Meta:
        db_table='soil_texture'
        app_label='models_app'

class SoilReport(models.Model):
    field = models.ForeignKey(Field, on_delete=models.CASCADE,related_name='soilreport')
    
    ph = models.FloatField()
    ec = models.FloatField()

    nitrogen = models.FloatField(null=True, blank=True)
    phosphorous = models.FloatField()
    potassium = models.FloatField()
    
    boron = models.FloatField(null=True, blank=True)
    copper = models.FloatField(null=True, blank=True)
    iron = models.FloatField(null=True, blank=True)
    zinc = models.FloatField(null=True, blank=True)
    manganese = models.FloatField(null=True, blank=True)

    soil_type = models.ForeignKey(SoilTexture,on_delete=models.CASCADE)
    
    report_link=models.URLField(blank=True,null=True)
    class Meta:
        db_table='soil_report'
        app_label = 'models_app'  # Optional if model is inside the models_app app

