# app/models/asset.py

import os
from uuid import uuid4
from django.db import models
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey


def asset_upload_to(instance, filename):
    try:
        obj = instance.content_object  # e.g., a Field instance
        model_name = instance.content_type.model

        # Get user ID from: Field → Farm → User
        user_id = obj.user.id
    except Exception:
        user_id = 'unknown_user'

    # Generate a unique filename with extension
    ext = filename.split('.')[-1]
    unique_filename = f"{uuid4()}.{ext}"

    # Example: assets/field/23/99/uuid.jpg
    return os.path.join(
        'assets',
        model_name,
        str(user_id),
        str(instance.object_id),
        unique_filename
    )


class Asset(models.Model):
    file = models.FileField(upload_to=asset_upload_to)

    # Generic foreign key fields
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')

    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        app_label='models_app'
        db_table='asset'
        ordering = ['-uploaded_at']

    def __str__(self):
        return self.file.name
