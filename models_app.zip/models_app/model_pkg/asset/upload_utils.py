import os
from uuid import uuid4


def asset_upload_to(instance, filename):
    model_name = instance.__class__.__name__.lower()  # "field"
    
    # Use instance.user.id if available
    user_id = getattr(instance.user, 'id', 'unknown_user')

    # Use instance.pk — may be None during first save (before the DB assigns an ID)
    object_id = instance.pk or 'temp'

    ext = filename.split('.')[-1]
    unique_filename = f"{uuid4()}.{ext}"

    return os.path.join(
        'assets',
        model_name,
        str(user_id),
        str(object_id),
        unique_filename
    )
