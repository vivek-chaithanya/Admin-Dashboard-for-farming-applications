from django.contrib import admin

# Register your models here.
from models_app.models import *
from django.contrib.auth.admin import UserAdmin
from django.utils.translation import gettext_lazy as _
from django.utils.html import format_html

class CustomUserAdmin(UserAdmin):
    model = CustomUser
    list_display = ('email', 'username', 'phone_number', 'is_active', 'is_staff', 'is_superuser')
    list_filter = ('is_active', 'is_staff', 'is_superuser')
    ordering = ('email',)
    search_fields = ('email', 'username', 'phone_number')

    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        (_('Personal info'), {'fields': ('username', 'phone_number', 'google_id', 'avatar')}),
        (_('Permissions'), {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        (_('Important dates'), {'fields': ('last_login', 'date_joined')}),
    )

    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'password1', 'password2', 'is_staff', 'is_superuser'),
        }),
    )

admin.site.register(CustomUser, CustomUserAdmin)

@admin.register(UserAuthToken)
class UserAuthTokenAdmin(admin.ModelAdmin):
    list_display = ('user', 'access_token', 'last_login')
    search_fields = ('user__email', 'user__phone_number')


@admin.register(Farm)
class FarmAdmin(admin.ModelAdmin):
    list_display = ('name', 'user')
    search_fields = ('name', 'user__email')
    list_filter = ('user',)


@admin.register(Field)
class FieldAdmin(admin.ModelAdmin):
    list_display = ('name', 'farm', 'crop', 'crop_variety', 'location_name', 'is_active', 'created_at', 'updated_at','image')
    list_filter = ('farm', 'crop', 'crop_variety', 'is_active')
    search_fields = ('name', 'location_name', 'farm__name', 'crop__name', 'crop_variety__name')
    readonly_fields = ('area', 'created_at', 'updated_at')
    ordering = ('name',)

    fieldsets = (
        (None, {
            'fields': ('name', 'farm', 'device', 'crop', 'crop_variety', 'location_name', 'is_active')
        }),
        ('Geography & Area', {
            'fields': ('boundary', 'area'),
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
        }),
    )


@admin.register(Device)
class DeviceAdmin(admin.ModelAdmin):
    list_display = ('name', 'user')
    search_fields = ('name', 'user__email', 'user__phone_number')
    list_filter = ('user',)


@admin.register(Crop)
class CropAdmin(admin.ModelAdmin):
    list_display = ('name', 'icon_preview')
    search_fields = ('name',)
    readonly_fields = ('icon_preview',)
    fields = ('name', 'icon_url', 'icon_preview')

    def icon_preview(self, obj):
        if obj.icon_url:
            return format_html('<img src="{}" style="height:30px;" />', obj.icon_url)
        return "-"
    icon_preview.short_description = "Icon"


@admin.register(CropVariety)
class CropVarietyAdmin(admin.ModelAdmin):
    list_display = ('name', 'crop', 'is_primary')
    list_filter = ('crop', 'is_primary')
    search_fields = ('name', 'crop__name')



# -----------------------------
# Feature Admin
# -----------------------------
@admin.register(FeatureType)
class FeatureTypeAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'description', 'created_at', 'updated_at')
    search_fields = ('name',)
    ordering = ('id',)

@admin.register(Feature)
class FeatureAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'feature_type', 'created_at', 'updated_at')
    list_filter = ('feature_type',)
    search_fields = ('name',)
    ordering = ('id',)


# -----------------------------
# Plan Admins
# -----------------------------
@admin.register(MainPlan)
class MainPlanAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'price', 'created_at', 'updated_at')
    search_fields = ('name',)
    ordering = ('id',)


@admin.register(TopUpPlan)
class TopUpPlanAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'price', 'parent_main_plan', 'created_at', 'updated_at')
    list_filter = ('parent_main_plan',)
    search_fields = ('name',)
    ordering = ('id',)


@admin.register(EnterprisePlan)
class EnterprisePlanAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'price', 'created_at', 'updated_at')
    search_fields = ('name',)
    ordering = ('id',)


# -----------------------------
# Plan-Feature Mapping Admins
# -----------------------------
@admin.register(MainPlanFeature)
class MainPlanFeatureAdmin(admin.ModelAdmin):
    list_display = ('id', 'plan', 'feature', 'max_count', 'duration_days', 'created_at', 'updated_at')
    list_filter = ('plan', 'feature')
    ordering = ('id',)


@admin.register(TopUpPlanFeature)
class TopUpPlanFeatureAdmin(admin.ModelAdmin):
    list_display = ('id', 'plan', 'feature', 'max_count', 'duration_days', 'created_at', 'updated_at')
    list_filter = ('plan', 'feature')
    ordering = ('id',)


@admin.register(EnterprisePlanFeature)
class EnterprisePlanFeatureAdmin(admin.ModelAdmin):
    list_display = ('id', 'plan', 'feature', 'max_count', 'duration_days', 'created_at', 'updated_at')
    list_filter = ('plan', 'feature')
    ordering = ('id',)


# -----------------------------
# User Plan Admins
# -----------------------------
@admin.register(MainUserPlan)
class MainUserPlanAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'plan', 'start_date', 'end_date', 'expire_at', 'is_active')
    list_filter = ('plan', 'is_active')
    search_fields = ('user__username', 'user__email', 'user__phone_number')
    ordering = ('id',)


@admin.register(TopUpUserPlan)
class TopUpUserPlanAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'plan', 'purchase_date', 'expire_at', 'is_active')
    list_filter = ('plan', 'is_active')
    search_fields = ('user__username', 'user__email', 'user__phone_number')
    ordering = ('id',)


@admin.register(EnterpriseUserPlan)
class EnterpriseUserPlanAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'plan', 'start_date', 'end_date', 'expire_at', 'is_active')
    list_filter = ('plan', 'is_active')
    search_fields = ('user__username', 'user__email', 'user__phone_number')
    ordering = ('id',)


# -----------------------------
# Feature Usage Tracking Admins
# -----------------------------
@admin.register(MainPlanFeatureUsage)
class MainPlanFeatureUsageAdmin(admin.ModelAdmin):
    list_display = ('id', 'user_plan', 'feature', 'used_count', 'duration_days', 'created_at', 'updated_at')
    list_filter = ('feature',)
    ordering = ('id',)


@admin.register(TopUpPlanFeatureUsage)
class TopUpPlanFeatureUsageAdmin(admin.ModelAdmin):
    list_display = ('id', 'user_plan', 'feature', 'used_count', 'duration_days', 'created_at', 'updated_at')
    list_filter = ('feature',)
    ordering = ('id',)


@admin.register(EnterprisePlanFeatureUsage)
class EnterprisePlanFeatureUsageAdmin(admin.ModelAdmin):
    list_display = ('id', 'user_plan', 'feature', 'used_count', 'duration_days', 'created_at', 'updated_at')
    list_filter = ('feature',)
    ordering = ('id',)
