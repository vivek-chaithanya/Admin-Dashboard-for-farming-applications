from django.db.models.signals import post_migrate
from django.dispatch import receiver
from models_app.models import SubscriptionPlan

@receiver(post_migrate)
def create_free_subscription_plan(sender, **kwargs):
    if sender.name != 'models_app':
        return  # Only run when your app is migrated

    SubscriptionPlan.objects.get_or_create(
        name='free',
        price= 0
    )
